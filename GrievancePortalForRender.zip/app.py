
from flask import Flask, render_template, request
import json
import os

app = Flask(__name__)

DATA_FILE = "grievances.json"

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", submitted=False)

@app.route("/submit", methods=["POST"])
def submit():
    data = {
        "title": request.form.get("title"),
        "complaint": request.form.get("complaint"),
        "mood": request.form.get("mood"),
        "severity": request.form.get("severity")
    }

    # Load existing data
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            grievances = json.load(f)
    else:
        grievances = []

    grievances.append(data)

    # Save updated data
    with open(DATA_FILE, "w") as f:
        json.dump(grievances, f, indent=2)

    return render_template("index.html", submitted=True)

if __name__ == "__main__":
    app.run(debug=True)
